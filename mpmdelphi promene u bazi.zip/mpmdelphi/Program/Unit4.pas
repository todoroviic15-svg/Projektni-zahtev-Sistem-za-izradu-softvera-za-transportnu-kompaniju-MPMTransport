unit Unit4;

interface

uses
  System.SysUtils, System.Types, System.UITypes, System.Classes, System.Variants,
  FMX.Types, FMX.Controls, FMX.Forms, FMX.Graphics, FMX.Dialogs,
  FMX.Controls.Presentation, FMX.StdCtrls, Unit2, FMX.Objects, FMX.Maps;

type
  TForm4 = class(TForm)
    SpeedButton1: TSpeedButton;
    MapView1: TMapView;
    Text1: TText;
    btnChat: TButton;
    btnOtvoriNalog: TButton;
    btnUpravljajNalozima: TButton;
    procedure SpeedButton1Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form4: TForm4;

implementation

{$R *.fmx}

procedure TForm4.SpeedButton1Click(Sender: TObject);
begin
Form2.Show;
Close;
end;

end.
